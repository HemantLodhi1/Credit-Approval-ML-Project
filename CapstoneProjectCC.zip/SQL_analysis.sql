CREATE DATABASE IF NOT EXISTS credit_analysis;
USE credit_analysis;
select * from credit_data;
select * from credit_label;

/* Group by Income Type and Find Average Annual Income: */
SELECT Type_Income, AVG(Annual_income) AS Average_Income
FROM credit_data
GROUP BY Type_Income;
/*
Result 
Pensioner	155604.9847
Commercial associate	233855.0847
Working	180999.1865
State servant	211422.4138
*/

/* Find Female Owners of Cars and Property:*/
SELECT *
FROM credit_data
WHERE GENDER = 'F' AND Car_Owner = 'Y' AND Propert_Owner = 'Y';
/* 
Top 4 Result 
5018498	F	Y	Y	0	90000	Working	Secondary / secondary special	Married	House / apartment	-18950	-1002	1	1	1	0	Cooking staff	2
5018503	F	Y	Y	0	90000	Working	Secondary / secondary special	Married	House / apartment	-18950	-1002	1	1	1	0	Cooking staff	2
5024213	F	Y	Y	0	540000	Commercial associate	Higher education	Married	House / apartment	-15702	-185	1	0	1	0		2
5036660	F	Y	Y	0	76500	Pensioner	Secondary / secondary special	Married	House / apartment	-23835	365243	1	0	0	0		2
*/

/* Find Male Customers Staying with Families:*/
SELECT *
FROM credit_data
WHERE GENDER = 'M' AND Family_Members > 1;

select count(ind_id) as MaleWithFamily 
FROM credit_data
WHERE
GENDER = 'M' AND Family_Members > 1;

/* 
RESULT 
there are 456 male with family */

/* top Five People with Highest Income:*/
SELECT Ind_ID, Annual_income
FROM credit_data
ORDER BY Annual_income DESC
LIMIT 5;
/* 
RESULT 
5079017	900000
5090470	900000
5079016	900000
5143231	1575000
5143235	1575000*/

/* Married People with Bad Credit: */
SELECT COUNT(*)
FROM credit_data cd
JOIN credit_label cl ON cd.Ind_ID = cl.Ind_ID
WHERE Marital_status = 'Married' AND label = 1;
/*
RESULT 
There are 108 Married People with Bad Credit 
*/

/* Highest Education Level and Total Count: */
SELECT EDUCATION, COUNT(*) AS Total
FROM credit_data
GROUP BY EDUCATION
ORDER BY Total DESC
LIMIT 1;
/*
RESULT 
Secondary / secondary special	1000
*/

/* Married Males and Females with Bad Credit: */ 
SELECT GENDER, COUNT(*)
FROM credit_data cd
JOIN credit_label cl ON cd.Ind_ID = cl.Ind_ID
WHERE Marital_status = 'Married' AND label = 1
GROUP BY GENDER;
/* 
RESULT 
M	50
F	54
	4
    */
    
    